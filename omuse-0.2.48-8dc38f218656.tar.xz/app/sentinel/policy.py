from __future__ import annotations
from dataclasses import dataclass, field
from urllib.parse import urlparse
from app.sentinel import guard
from app.sentinel.catalog import TOOLS
ALLOW, DENY, ASK = ('ALLOW', 'DENY', 'ASK_USER')
RISK_ORDER = {'low': 0, 'medium': 1, 'high': 2, 'critical': 3}
PER_USE_TOOLS = {'browser_fill_secret'}
BULK_MAIL = 5

@dataclass
class Decision:
 decision: str
 risk: str
 reason: str = ''
 destination: str = ''
 grant_id: str = ''
 notes: list[str] = field(default_factory=list)

def _bump(risk: str, to: str) -> str:
 return to if RISK_ORDER[to] > RISK_ORDER[risk] else risk

def destination(tool: str, args: dict, elem: dict | None=None, page: dict | None=None) -> str:
 if tool in ('gmail_send', 'gmail_create_draft', 'gmail_forward'):
  rec = ','.join(sorted((x.strip().lower() for x in f'{args.get('to', '')},{args.get('cc', '')}'.split(',') if x.strip())))
  return rec
 if tool == 'gmail_reply':
  return f'reply:{args.get('message_id', '')}'
 if tool.startswith('browser_'):
  url = args.get('url') or (page or {}).get('url', '')
  return guard.domain_of(url)
 if tool == 'slack_send_message':
  return f'slack:{str(args.get('channel', '')).lstrip('#').lower()}'
 if tool.startswith('notion_') and tool not in ('notion_search', 'notion_get_page', 'notion_query_database'):
  return f'notion:{args.get('parent_id') or args.get('page_id') or ''}'
 if tool == 'phone_call':
  from app.sentinel.phone import normalize
  return f'tel:{normalize(str(args.get('to', '')))}'
 return ''

def decide(store, tool: str, args: dict, task_id: str, *, elem: dict | None=None, page: dict | None=None, gmail_ready: bool=True) -> Decision:
 t = TOOLS.get(tool)
 if not t:
  return Decision(DENY, 'high', f'未知工具 unknown tool: {tool}')
 if str(t['connector']).startswith('mcp:'):
  return _decide_mcp(store, tool, t, args, task_id)
 conn = store.connection(t['connector'])
 if not conn['enabled']:
  return Decision(DENY, t['risk'], f'连接「{t['connector']}」未启用 (connector disabled)')
 if not conn['permissions'].get(t['capability'], False):
  return Decision(DENY, t['risk'], f'权限「{t['connector']}.{t['capability']}」已关闭 (permission off in Connections)')
 if t['connector'] == 'gmail' and (not gmail_ready):
  return Decision(DENY, t['risk'], '邮箱尚未连接：请在「连接 Connections」页添加邮箱 (no mailbox connected)')
 risk = t['risk']
 reasons: list[str] = []
 ctx = store.task_ctx(task_id)
 tainted = guard.LEVELS.get(ctx['taint'], 0) >= guard.LEVELS['CONFIDENTIAL']
 dest = destination(tool, args, elem, page)
 if tool == 'browser_navigate':
  url = str(args.get('url', ''))
  ok, why = guard.check_url(url)
  if not ok:
   return Decision(DENY, 'high', why)
  dom = guard.domain_of(url)
  cfg = conn['config']
  if dom in set(cfg.get('blocked_domains') or []):
   return Decision(DENY, 'high', f'域名 {dom} 在黑名单中 (blocked domain)')
  p = urlparse(url)
  carries_data = bool(p.query) or len(p.path or '') > 60
  trusted = dom in set(cfg.get('allowed_domains') or [])
  if tainted and dom not in ctx['domains'] and (not trusted) and carries_data:
   risk = _bump(risk, 'high')
   reasons.append('本任务已读取机密数据（邮件等），且此网址带有参数，可能造成数据外泄 (data egress check)')
  elif ctx['injection'] and dom not in ctx['domains'] and (not trusted) and carries_data:
   risk = _bump(risk, 'high')
   reasons.append('本任务读到疑似提示注入的内容后，要访问一个带参数的新网址 (possible exfiltration after injection)')
 if tool == 'browser_read':
  cfg = conn['config']
  urls = args.get('urls') or ([args['url']] if args.get('url') else [])
  if isinstance(urls, str):
   urls = [urls]
  if not urls:
   return Decision(DENY, 'low', '缺少参数 urls (give 1–4 URLs)')
  for u in [str(x) for x in urls][:4]:
   ok, why = guard.check_url(u)
   if not ok:
    return Decision(DENY, 'high', f'{why}: {u[:80]}')
   dom = guard.domain_of(u)
   if dom in set(cfg.get('blocked_domains') or []):
    return Decision(DENY, 'high', f'域名 {dom} 在黑名单中 (blocked domain)')
   p = urlparse(u)
   carries_data = bool(p.query) or len(p.path or '') > 60
   if tainted and dom not in ctx['domains'] and (dom not in set(cfg.get('allowed_domains') or [])) and carries_data:
    risk = _bump(risk, 'high')
    reasons.append('本任务已读取机密数据，且此网址带有参数，可能造成数据外泄 (data egress check)')
    break
 if tool == 'browser_save_media':
  if args.get('url') and (not str(args['url']).startswith('data:')):
   ok, why = guard.check_url(str(args['url']))
   if not ok:
    return Decision(DENY, 'high', why)
   mdom = guard.domain_of(str(args['url']))
   if mdom in set(conn['config'].get('blocked_domains') or []):
    return Decision(DENY, 'high', f'域名 {mdom} 在黑名单中 (blocked domain)')
  if not args.get('ref') and (not args.get('url')):
   return Decision(DENY, 'low', '缺少参数：要给出图片/视频元素的 ref（如 e12）或者它的 url。Missing argument: pass ref (the [eN] of the photo or video in the snapshot) or url (its address). For charts, use make_chart instead')
 if tool in ('browser_click', 'browser_click_at', 'browser_type', 'browser_select', 'browser_press', 'browser_upload', 'browser_save_media') and page:
  dom = guard.domain_of(page.get('url', ''))
  if dom and dom in set(conn['config'].get('blocked_domains') or []):
   return Decision(DENY, 'high', f'域名 {dom} 在黑名单中 (blocked domain)')
 if tool == 'browser_click_at' and (not (elem and elem.get('tag'))):
  risk = _bump(risk, 'high')
  reasons.append("无法确认这个位置上是什么元素 (can't tell what is at this position)")
 if tool in ('browser_click', 'browser_click_at') and elem:
  itype = elem.get('input_type', '') if elem.get('in_form', True) else ''
  if guard.click_is_risky(elem.get('role', ''), elem.get('name', ''), itype):
   risk = _bump(risk, 'high')
   reasons.append(f'点击的按钮「{elem.get('name', '')}」可能提交/购买/发送/删除 (consequential click)')
 if tool == 'browser_type' or (tool == 'browser_click_at' and args.get('text')):
  if elem and (elem.get('input_type', '').lower() == 'password' or elem.get('is_password')):
   return Decision(DENY, 'high', 'Agent 不能输入密码。请调用 browser_request_takeover 让用户接管输入 (use takeover for passwords)')
  text = str(args.get('text', ''))
  is_search = elem and guard.looks_like_search(elem.get('role', ''), elem.get('name', ''))
  if args.get('submit') and (not is_search):
   risk = _bump(risk, 'high')
   reasons.append('输入后会按回车提交表单 (submits a form)')
  elif tainted and len(text) > 40 and (not is_search):
   risk = _bump(risk, 'high')
   reasons.append('本任务读取过机密数据，正在把较长文本输入网页 (possible data egress)')
  elif not is_search:
   risk = _bump(risk, 'medium')
 if tool == 'browser_fill_secret':
  from app.sentinel import vault
  it = vault.item(store, str(args.get('item_id', '')))
  field = str(args.get('field', ''))
  if not it:
   return Decision(DENY, 'high', '保险箱里没有这一项，请先用 vault_list 查看 (unknown vault item)')
  if field not in it['fields']:
   return Decision(DENY, 'high', f'「{it['label']}」没有字段 {field}，可用字段：{', '.join(it['fields'])} (unknown field)')
  if not elem or not page:
   return Decision(DENY, 'high', '找不到要填写的输入框，请先获取页面快照 (input not found — take a snapshot first)')
  tag = str(elem.get('tag', '')).lower()
  if elem.get('input_type', '').lower() == 'password' or elem.get('is_password'):
   return Decision(DENY, 'high', '不能把保险箱内容填进密码框 (never into a password field)')
  if tag not in ('input', 'textarea') and (not elem.get('editable')):
   return Decision(DENY, 'high', f'目标元素不是输入框（{tag}）(target is not a text input)')
  dom = guard.domain_of(page.get('url', ''))
  if not dom:
   return Decision(DENY, 'high', '无法确定当前网站 (unknown site)')
  if dom in set(conn['config'].get('blocked_domains') or []):
   return Decision(DENY, 'high', f'域名 {dom} 在黑名单中 (blocked domain)')
  if not vault.domain_ok(it, dom):
   return Decision(DENY, 'high', f'「{it['label']}」只允许在 {', '.join(it['domains'])} 使用，当前网站是 {dom} (item restricted to other sites)')
  risk = 'high'
  reasons.append(f'把保险箱里的「{vault.summary_text(it, field)}」填到 {dom} 的输入框（每次使用都需要你批准）(fills a vault value — approved per use)')
  if urlparse(page.get('url', '')).scheme != 'https' and (not (dom.endswith('.test') or dom in ('localhost', '127.0.0.1'))):
   reasons.append('⚠ 这个页面不是 HTTPS 加密连接 (page is not HTTPS)')
 if tool == 'browser_press' and str(args.get('key', '')).lower() in ('enter', 'return'):
  if elem and (not guard.looks_like_search(elem.get('role', ''), elem.get('name', ''))) and elem.get('in_form'):
   risk = _bump(risk, 'high')
   reasons.append('回车会提交表单 (Enter submits a form)')
 if tool == 'browser_upload':
  reasons.append('上传本地文件到网站 (uploads a local file)')
 if tool in ('gmail_send', 'gmail_reply', 'gmail_forward'):
  reasons.append('对外发送邮件 (sends email on your behalf)')
 if tool in ('gmail_archive', 'gmail_label'):
  n = len(args.get('message_ids') or [])
  labels = [str(x).lower() for x in (args.get('remove_labels') or []) + (args.get('add_labels') or [])]
  moves = tool == 'gmail_archive' or any((x in ('\\inbox', 'inbox', '\\trash', 'trash', '\\spam', 'spam') for x in labels))
  if moves and (n > BULK_MAIL or store.count_done(task_id, ('gmail_archive', 'gmail_label')) >= 2):
   risk = _bump(risk, 'high')
   reasons.append(f'将批量移动 {n} 封邮件（移出收件箱/垃圾箱）(bulk change: {n} emails leave the inbox)')
 if tool == 'gmail_unsubscribe':
  reasons.append(f'将代表你退订 {len(args.get('message_ids') or [])} 个发件方（发送退订请求/退订邮件）(unsubscribes on your behalf)')
 if t['connector'] in ('notion', 'slack') and (not store.has_secret(f'cred_{t['connector']}_1')):
  return Decision(DENY, t['risk'], f'{t['connector'].title()} 尚未连接：请在「连接 Connections」页设置 (not connected)')
 if tool == 'slack_send_message':
  reasons.append('代表你在 Slack 发送消息 (posts to Slack on your behalf)')
 if tool == 'notion_update_page' and args.get('archived'):
  risk = _bump(risk, 'high')
  reasons.append('将归档（删除）一个 Notion 页面 (archives a Notion page)')
 if t['connector'] == 'calendar':
  if not store.has_secret('cred_calendar_1'):
   return Decision(DENY, t['risk'], 'Google 日历尚未连接：请在「连接 Connections」页设置 (not connected)')
  if t['capability'] == 'write' and (store.get_secret('cred_calendar_1') or {}).get('ical_url'):
   from app.sentinel.ical import READ_ONLY
   return Decision(DENY, t['risk'], READ_ONLY)
  if tool == 'calendar_create_event' and args.get('attendees'):
   risk = _bump(risk, 'high')
   reasons.append('会给参会人发送日历邀请邮件 (sends calendar invitations)')
  elif tool == 'calendar_create_event' and tainted and (len(str(args.get('description') or '')) > 300):
   risk = _bump(risk, 'high')
   reasons.append('本任务读取过机密数据，这次要把较长的内容写进日程 (possible data egress)')
  if tool == 'calendar_update_event':
   reasons.append('修改已有日程，参会人会收到更新 (changes an existing event)')
  if tool == 'calendar_delete_event':
   reasons.append('删除日程，参会人会收到取消通知 (deletes an event)')
 if t['connector'] == 'phone':
  from app.sentinel import phone
  if not phone.ready(store):
   return Decision(DENY, t['risk'], '电话功能还没配置好：请在「连接 → 电话」连接 DialMCP 或填写 Telnyx 设置 (phone not configured)')
  if tool == 'phone_call':
   cfg = phone.config(store)
   n, line, why = phone.check_call(store, str(args.get('to', '')), cfg)
   if not n:
    return Decision(DENY, 'high', why, dest)
   if phone.calls_today(store) >= cfg['daily_limit']:
    return Decision(DENY, 'high', f'今天已达到拨打上限 {cfg['daily_limit']} 通 (daily call limit reached)', dest)
   if len(str(args.get('purpose') or '').strip()) < 10:
    return Decision(DENY, 'high', '请写清楚这通电话要做什么 (purpose is required)', dest)
   reasons.append('用你自己的号码通过 DialMCP 打电话，对方看到的是你的号码，通话会录音 (places a call from your own number via DialMCP; recorded)' if line == 'dialmcp' else '用你的名义打电话，语音 AI 会和对方实时对话（按通话时长计费）(places a phone call on your behalf)')
 if ctx['injection'] and RISK_ORDER[risk] >= RISK_ORDER['medium']:
  risk = _bump(risk, 'high')
  reasons.append(f'本任务读到的外部内容疑似包含提示注入，所有写操作需要人工确认 (prompt-injection suspected: {', '.join(ctx['injection'])})')
 return _finish(store, tool, task_id, risk, reasons, dest, ctx)

def _finish(store, tool: str, task_id: str, risk: str, reasons: list[str], dest: str, ctx: dict) -> Decision:
 reason = '；'.join(reasons)
 if RISK_ORDER[risk] < RISK_ORDER['high']:
  return Decision(ALLOW, risk, reason, dest)
 if not ctx['injection'] and tool not in PER_USE_TOOLS:
  for g in store.active_grants():
   if g['tool'] != tool:
    continue
   if g['scope'] == 'TASK' and g['task_id'] != task_id:
    continue
   want = (g['match'] or {}).get('destination')
   if want and want != dest:
    continue
   return Decision(ALLOW, risk, f'已有授权 (granted: {g['scope']})', dest, grant_id=g['id'])
 return Decision(ASK, risk, reason or '高风险操作需要你的批准 (high-risk action)', dest)

def _decide_mcp(store, tool: str, t: dict, args: dict, task_id: str) -> Decision:
 from app.sentinel import mcp_hub
 s, rec = mcp_hub.tool_info(store, tool)
 if not s or not rec:
  return Decision(DENY, 'high', '这个 MCP 工具已被移除 (tool removed)')
 if not s.get('enabled', True):
  return Decision(DENY, t['risk'], f'MCP 服务器「{s['name']}」已停用 (server disabled in Connections)')
 if rec.get('mode') == 'off':
  return Decision(DENY, t['risk'], f'MCP 工具「{rec['name']}」已关闭 (tool off in Connections)')
 if rec.get('status') != 'ok':
  return Decision(DENY, 'high', f'MCP 工具「{rec['name']}」的定义有变化，需要你在「连接」页检查后才能使用 (tool definition changed — review it in Connections)')
 read = rec.get('kind') == 'read'
 risk = 'low' if read else 'medium'
 reasons: list[str] = []
 ctx = store.task_ctx(task_id)
 tainted = guard.LEVELS.get(ctx['taint'], 0) >= guard.LEVELS['CONFIDENTIAL']
 size = len(str(args or ''))
 if rec.get('mode') == 'ask':
  risk = 'high'
  reasons.append(f'你设置了「{s['name']} · {rec['name']}」每次都需要审批 (set to ask every time)')
 if not read:
  reasons.append(f'会修改「{s['name']}」里的数据 (writes to {s['name']})')
  if tainted and guard.LEVELS.get(ctx['taint'], 0) > guard.LEVELS.get(s.get('data_class') or 'CONFIDENTIAL', 2):
   risk = _bump(risk, 'high')
   reasons.append('本任务读取过更机密的数据，现在要写入一个外部服务 (data egress check)')
  elif tainted and size > 300:
   risk = _bump(risk, 'high')
   reasons.append('本任务读取过机密数据（邮件等），且这次要写入较多内容 (possible data egress)')
 elif tainted and size > 500 and (guard.LEVELS.get(ctx['taint'], 0) > guard.LEVELS.get(s.get('data_class') or 'CONFIDENTIAL', 2)):
  risk = _bump(risk, 'high')
  reasons.append('本任务读取过机密数据，这次查询参数很长，可能把数据带出去 (possible data egress in query)')
 if ctx['injection'] and (not read):
  risk = _bump(risk, 'high')
  reasons.append(f'本任务读到的外部内容疑似包含提示注入，所有写操作需要人工确认 (prompt-injection suspected: {', '.join(ctx['injection'])})')
 return _finish(store, tool, task_id, risk, reasons, s['id'], ctx)
